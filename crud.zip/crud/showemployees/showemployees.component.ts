import { Component, OnInit } from '@angular/core';
import data from '../data/addemp.json';
import { UpdateserviceService } from '../updateservice.service';


@Component({
  selector: 'app-showemployees',
  templateUrl: './showemployees.component.html',
  styleUrls: ['./showemployees.component.css']
})
export class ShowemployeesComponent implements OnInit {
array=data
  constructor(private service:UpdateserviceService) { }

  ngOnInit() {
  }
  
  DeleteData(i)
  {
    data.splice(i,1)
  }
  public updatedata(i:number)
  {
    this.service.upsend(i);
  }
}
