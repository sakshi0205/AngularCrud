import { Component, OnInit } from '@angular/core';
import data from '../data/addemp.json';
import { UpdateserviceService } from '../updateservice.service';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {
   array=data
   emp:any
   empId:any
   empName:any
   empSal:any
   empDep:any
   index=null;

  constructor(private service: UpdateserviceService) { }

  ngOnInit() {
     if(this.service.subsVar==undefined)
     {
       this.service.subsVar=this.service.invokeupdate.subscribe((i:number) => { this.view(i)
      });
     }
  }
  view(i:number)
  {
    this.empId=this.array[i].empId
    this.empName=this.array[i].empName
    this.empSal=this.array[i].empSal
    this.empDep=this.array[i].empDep
    this.index=i
  }
  updateEmployee(form)
  {
    this.array.splice(this.index,1,{
      empId:this.empId,
      empName:this.empName,
      empSal:this.empSal,
      empDep:this.empDep
    })
  }

}
