import { Component, OnInit } from '@angular/core';
import data from '../data/addemp.json';


@Component({
  selector: 'app-labaddemp',
  templateUrl: './labaddemp.component.html',
  styleUrls: ['./labaddemp.component.css']
})
export class LabaddempComponent implements OnInit {
  array = data
  constructor() { }

  ngOnInit() {
  }

 // addEmployee(add){
  //console.log("Before Adding ",add.empId,add.empName,add.empSal,add.empDep);
    //this.employees.push(add);
   //alert(add.empId + " " +add.empName + " " + add.empSal + " " + add.empDep);
 // }
  //deletedata(i) {
   // this.employees.splice(i, 1)
  //}
    addEmployee(add)
    {
        this.array.push({
          empId:add.empId,
          empName:add.empName,
          empSal:add.empSal,
          empDep:add.empDep

        });
    }
 
}