import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabaddempComponent } from './labaddemp.component';

describe('LabaddempComponent', () => {
  let component: LabaddempComponent;
  let fixture: ComponentFixture<LabaddempComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabaddempComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabaddempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
