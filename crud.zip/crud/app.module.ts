import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { PipePipe } from './pipe.pipe';
import { EmployeeComponent } from './employee/employee.component';
import { ShowstudentsComponent } from './showstudents/showstudents.component';
import { ShowemployeesComponent } from './showemployees/showemployees.component';
import { AddresscardComponent } from './addresscard/addresscard.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import {AppRoutingModule} from './app-routing.module';
import { ShowhttpdataComponent } from './showhttpdata/showhttpdata.component'
import { HttpClientModule} from  '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { LoginformComponent } from './loginform/loginform.component';
import { LabaddempComponent } from './labaddemp/labaddemp.component';
import { ProductComponent } from './product/product.component';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';


@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    PipePipe,
    EmployeeComponent,
    ShowstudentsComponent,
    ShowemployeesComponent,
    AddresscardComponent,
    AddemployeeComponent,
   ShowhttpdataComponent,
    LoginComponent,
    LoginformComponent,
    LabaddempComponent,
    ProductComponent,
    UpdateemployeeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

