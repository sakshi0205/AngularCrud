import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShowstudentsComponent } from './showstudents/showstudents.component';
import { ShowemployeesComponent } from './showemployees/showemployees.component'
import { FormComponent } from './form/form.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ShowhttpdataComponent} from  './showhttpData/showhttpdata.component';
import { LoginComponent } from './login/login.component';
import { LabaddempComponent } from './labaddemp/labaddemp.component';

const routes: Routes = [
  {
    path: 'addemployee',
    component: AddemployeeComponent
  },
  {
    path : 'login',
    component: LoginComponent

  },
  {
    path : 'labaddemp',
    component: LabaddempComponent

  },
  {
    path: 'showstudents',
    component: ShowstudentsComponent
  },

  {
    path: 'showemployees',
    component: ShowemployeesComponent
  },
  {
    path: '',
    component: FormComponent
  }];
@NgModule({
  imports: [RouterModule.forRoot(routes),],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
